Installation:


1) Go to Eclipse Marketplace
2) Search "TestNG for Eclipse"

And Create TestNG class in Java or Web Project
