package com.app;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookSel {

	WebDriver driver;
	
	public void invokeBrowser() {
		
		System.setProperty("webdriver.chrome.driver","D:\\SELENIUM\\selenium-java-3.141.59 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		driver.get("https://www.facebook.com/");
	}
public void performFunc() {
		
	driver.findElement(By.name("firstname")).sendKeys("Archit");
	driver.findElement(By.name("lastname")).sendKeys("Agarwal");
	driver.findElement(By.name("reg_email__")).sendKeys("crazzylegs3sep@gmail.com");
	driver.findElement(By.name("reg_email_confirmation__")).sendKeys("crazzylegs3sep@gmail.com");
	driver.findElement(By.name("reg_passwd__")).sendKeys("Archit@123");
	driver.findElement(By.name("birthday_day")).sendKeys("3");
	driver.findElement(By.name("birthday_month")).sendKeys("Sept");
	driver.findElement(By.name("birthday_year")).sendKeys("1993");
	driver.findElement(By.id("u_0_7")).click();
	driver.findElement(By.name("websubmit")).click();
	
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FacebookSel test = new FacebookSel();
		test.invokeBrowser();
		test.performFunc();
	}

}
